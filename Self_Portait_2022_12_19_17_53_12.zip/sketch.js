let faceX;


function setup() {
  createCanvas(400, 400);
  faceX = width/2;
 
}
function draw() {
  fill('#D2B29C');
   console.log("x: " + mouseX + ", y: " + mouseY);
  background(180);
ellipse(faceX,191,190,220);
  fill(255);
  ellipse(faceX*156/200,180,30,30);
  push();
  fill(0);
  ellipse(159,183,15,15);//left eye
  pop();
  fill(255);
  ellipse(245,180,30,30)
  push();
  fill(0)
ellipse(243,183,15,15); //right eye
  pop();
  

  
  beginShape();
  vertex(107,206);
  quadraticVertex(125,250,200,253);
  quadraticVertex(275,250,294,206);
  quadraticVertex(283,296,200,301);
  quadraticVertex(110,300,105,195);
  fill(0);
  
  endShape();

  beginShape();
  vertex(169,276);
  vertex(169,249);
  vertex(231,249);
  vertex(231,276);
  vertex(200,298);
  vertex(169,276);
  fill('#D2B29C');
  endShape();
  beginShape();
  vertex(175,260);
  vertex(225,260);
  vertex(200,280);
  vertex(175,260);
  fill(255);
  endShape();
  
  beginShape();
  vertex(124,125);
  quadraticVertex(150,80,196,81);
  quadraticVertex(250,81,274,124);
  

  fill(0);
  endShape();
  
  beginShape();
  vertex(112,146);
  vertex(138,142);
  quadraticVertex(138,140,132,113); 
  fill(0);
  endShape();
  
  beginShape();
  vertex(288,146);
  vertex(262,142);
  quadraticVertex(262,140,268,113);
  fill(0);
  endShape();
}